To run mininet:
$ sudo python topo.py

To run controller:
$ ryu-manager ryu_lab4.py --observe-links